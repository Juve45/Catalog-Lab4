/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

import java.io.File;

/**
 *
 * @author alexandru
 */
public class Song extends Item{
    
    private String title;
    
    public Song(String filePath) {
        super(filePath);
    }
    
    
    public void setTitle(String title)
    {
        this.title = title;
    }
    
    public String title()
    {
        return title;
    }
    
    public String toString()
    {
        return title;
    }
    
}
