/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

import java.io.IOException;

/**
 *
 * @author alexandru
 */
public class Lab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        Item it = new Item("/home/alexandru/asd.mp4");
        Item it2 = new Item("/home/alexandru/Pictures/a.png");
        //Item it3 = new Item("/home/alexandasru/Pigctures/a35.png");
        //it3.play();
        Song s=new Song("/home/alexandru/asd.mp4");
        s.setTitle("ASD");
        Item it4 = new Item("/home/alexandru/Pictures/a.png");
        Catalog c = new Catalog();
        c.add(it);
        c.add(it2);
        c.add(s);
        c.add(it4);
        
        c.save("fisier2");
        c.load("fisier2");
        c.list();
        /*
        for(Item i:c.getItemList())
        {
            i.play();
        }
*/
    }
    
}
